import datetime
import json
from pathlib import Path
import requests
import aiohttp
from sqlalchemy import *
from sqlalchemy.orm import Session, declarative_base

engine = create_engine("postgresql+psycopg2://test:Some_password@localhost/test_base")
session = Session(bind=engine)
BASE_DIR = Path(__file__).resolve().parent.parent

Base = declarative_base()

class About(Base):
    __tablename__ = 'Aboutt'
    id = Column(Integer, primary_key=True, autoincrement=True)
    text = Column('content', Text(), nullable=False)
    pic = Column('pic', Text(), default=None)

class Shops(Base):
    __tablename__ = 'Shops'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    pic = Column('pic', Text(), default=None)
    bot = Column('bot', Text(), default=None)
    site = Column('site', Text(), default=None)
    contacts = Column('contacts', Text(), default=None)
    callback_data = Column(Integer, autoincrement=True)
    status = Column(String(100), nullable=False) # checked, popular, new

class Rules(Base):
    __tablename__ = 'rules'
    id = Column(Integer, primary_key=True, autoincrement=True)
    text = Column('content', Text(), nullable=False)
    pic = Column('pic', Text(), default=None)

class Roulettes(Base):
    __tablename__ = 'roulettes'
    id = Column(Integer, primary_key=True, autoincrement=True)
    text = Column('content', Text(), nullable=False)
    pic = Column('pic', Text(), default=None)

class Admins(Base):
    __tablename__ = 'admins'
    id = Column(Integer, primary_key=True, autoincrement=True)
    user = Column(String(300), nullable=False)

class Users(Base):
    __tablename__ = 'users_bot'
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(300), nullable=False)
    tg_id = Column(Integer, nullable=False)


def is_admin(user):
    admins = session.query(Admins).all()
    for i in admins:
        if user.username == i.user:
            return True
        else:
            return False

def is_old_user(user):
    users = session.query(Users).filter(Users.username == user.username).first()
    if users:
        return True
    else:
        return False



Base.metadata.create_all(engine)