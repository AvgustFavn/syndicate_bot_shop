import asyncio
import os
from random import *
from aiogram import *
from aiogram.client import bot
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto, Bot, InputFile
from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler, ApplicationBuilder, \
    MessageHandler, filters
from back import *

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
loop = asyncio.get_event_loop()

async def start(update: Update, context: CallbackContext) -> None:
    user = update.effective_user
    print(user)
    if not is_old_user(user):
        u = Users(username=user.username, tg_id=user.id)
        session.add(u)
        session.commit()

    print(user)
    if not is_admin(user):
        keyboard = [
            [InlineKeyboardButton("О нас", callback_data='1'),
             InlineKeyboardButton("Магазины", callback_data='2')],
        ]
    else:
        keyboard = [
            [InlineKeyboardButton("О нас", callback_data='1'),
             InlineKeyboardButton("Магазины", callback_data='2'),
             InlineKeyboardButton("Админ панель", callback_data='8')],
        ]

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(text=f'Привет🫶! Я бот с магазинами и вкусностями 💊, посмотри меня :)',
                              reply_markup=reply_markup)


async def button(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    user = update.effective_user
    await query.answer()
    if query.data == '1':
        post = session.query(About).all()
        post = post[-1]

        keyboard = [
            [InlineKeyboardButton("Правила", callback_data='6'),
             InlineKeyboardButton("График рулеток", callback_data='7'),
             ],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        if post.pic:
            await context.bot.send_photo(photo=(open(f'{BASE_DIR}\\{post.pic}', "rb")),
                                   caption=post.text, reply_markup=reply_markup,
                                   chat_id=user.id)
        else:
            await query.edit_message_text(post.text, reply_markup=reply_markup)

    elif query.data == '2':
        keyboard = [
            [InlineKeyboardButton("Проверенные", callback_data='3'),
             InlineKeyboardButton("Популярные", callback_data='4'),
             InlineKeyboardButton("На испытательном", callback_data='5'),
             ],
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_photo(photo=(open(f'{BASE_DIR}\\media\\shops.jpg', "rb")),
                                       caption='Контакты всех магазинов собраны здесь 💖', reply_markup=reply_markup,
                                     chat_id=user.id)

    elif query.data == '3':
        shops = session.query(Shops).filter(Shops.status == 'checked')
        keyboard = []
        for i in shops:
            keyboard.append(InlineKeyboardButton(i.name, callback_data=i.callback_data))
        keyboard = [keyboard]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(
            chat_id=user.id,
            text=f'Магазины, которые проверены и с опытом :)',
            reply_markup=reply_markup
        )

    elif query.data == '4':
        shops = session.query(Shops).filter(Shops.status == 'popular')
        keyboard = []
        for i in shops:
            keyboard.append(InlineKeyboardButton(i.name, callback_data=i.callback_data))
        keyboard = [keyboard]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(
            chat_id=user.id,
            text=f'Магазины, которые особо популярны :)',
            reply_markup=reply_markup
        )

    elif query.data == '5':
        shops = session.query(Shops).filter(Shops.status == 'new')
        keyboard = []
        for i in shops:
            keyboard.append(InlineKeyboardButton(i.name, callback_data=i.callback_data))
        keyboard = [keyboard]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(
            chat_id=user.id,
            text=f'Магазины, которые появились у нас недавно :)',
            reply_markup=reply_markup
        )

    elif query.data == '6':
        rule = session.query(Rules).order_by(desc(Rules.id)).first()
        try:
            media = InputMediaPhoto(media=(open(f'{BASE_DIR}\\{rule.pic}', "rb")), caption=rule.text)
            await query.edit_message_media(media=media)
        except:
            await context.bot.send_message(
                chat_id=user.id,
                text=rule.text
            )

    elif query.data == '7':
        rul = session.query(Roulettes).order_by(desc(Roulettes.id)).first()
        try:
            media = InputMediaPhoto(media=(open(f'{BASE_DIR}\\{rul.pic}', "rb")), caption=rul.text)
            await query.edit_message_media(media=media)
        except:
            await context.bot.send_message(
                chat_id=user.id,
                text=rul.text
            )

    elif query.data == '8':
        if is_admin(user):
            keyboard = [
                [InlineKeyboardButton("Добавить Админа", callback_data='9')],
                 [InlineKeyboardButton("Убрать Админа", callback_data='10')],
                 [InlineKeyboardButton("Изменить правила", callback_data='11')],
                 [InlineKeyboardButton("Изменить график рулеток", callback_data='12')],
                 [InlineKeyboardButton("Изменить 'о нас'", callback_data='13')],
                 [InlineKeyboardButton("Добавить магазин", callback_data='14')],
                 [InlineKeyboardButton("Убрать магазин", callback_data='15')],
                 [InlineKeyboardButton("Изменить магазин", callback_data='16')],
                 [InlineKeyboardButton("Отправить сообщение всем", callback_data='17')], ] # Проверка кол-ва сообщений, присутсвие в каналах,

            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text('Админ панель', reply_markup=reply_markup)

    elif query.data == '9':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите имя пользователя с этой командой, пример: /new_admin username')

    elif query.data == '10':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите имя пользователя с этой командой, пример: /del_admin username')

    elif query.data == '11':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом: /new_rule Привет, вот новые правила, никаких фото!')

    elif query.data == '12':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом: /new_rullete Привет, вот новая инфа про рулетки!')

    elif query.data == '13':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом: /new_about Мы крутая площадка, где есть все-все!')

    elif query.data == '14':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом по шаблону, можете приложить '
                                                 f'картинку в одном сообщении с этим шаблоном! Вы так же можете добавить или не добавить бот/сайт/контакты. '
                                                 f'Так же вы должны указать статус магазина, они все: Проверенные, Популярные, На испытательном \n'
                                                 f'/new_shop Название: Зеленый магазин; Бот: google.ru; Сайт: google.com; '
                                                 f'Контакты: google.com; Статус: Проверенные;')

    elif query.data == '15':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом: /del_shop Зеленый магазин')

    elif query.data == '16':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом по шаблону, можете приложить '
                                                 f'картинку в одном сообщении с этим шаблоном, НЕ ПИШИТЕ ТО ЧТО НЕ ХОТИТЕ МЕНЯТЬ, кроме названия! Вы так же можете добавить или не добавить бот/сайт/контакты. '
                                                 f'Так же вы должны указать статус магазина, они все: Проверенные, Популярные, На испытательном \n'
                                                 f'/new_shop Название: Зеленый магазин; Бот: google.ru; Сайт: google.com; '
                                                 f'Контакты: google.com; Статус: Проверенные;')

    elif query.data == '17':
        user = update.effective_user
        if is_admin(user):
            await query.edit_message_text(text=f'Введите команду вместе с текстом и картинкой(опционально, в одном '
                                                 f'сообщении картинка и текст): /tell Теперь у нас есть пыльца феи!')

    elif int(query.data) > 2000:
        shop = session.query(Shops).filter(Shops.callback_data == int(query.data)).first()
        text =f'Магазин {shop.name}'
        if shop.bot:
            text += f'\nБот: {shop.bot}'
        if shop.site:
            text += f'\nСайт: {shop.site}'
        if shop.contacts:
            text += f'\nСайт: {shop.contacts}'

        try:
            await context.bot.send_photo(chat_id=query.message.chat_id,
                                         photo=open(f'{BASE_DIR}\\{shop.pic}'.replace('/', '\\'), "rb"))
            await query.edit_message_text(text)
        except:
            await query.edit_message_text(text=text)

async def new_admin(update, context):
    # Получаем аргумент из команды
    try:
        username = context.args[0]
        print(username)
        try:
            ad = Admins(user=username)
            session.add(ad)
            session.commit()
            await update.message.reply_text('Пользователь стал админом :)')
        except:
            await update.message.reply_text('Пользователь введен не верно :(')
    except IndexError:
        update.message.reply_text('Пожалуйста, укажите имя пользователя после команды.')


async def del_admin(update, context):
    username = context.args[0]
    try:
        i = session.query(Admins).filter(Admins.user == username).one()
        session.delete(i)
        session.commit()
        await update.message.reply_text('Пользователь удален из админов :)')
    except:
        await update.message.reply_text('Пользователь введен не верно :(')

async def new_rule(update, context):
    text = update.message.caption
    if not text:
        text = ' '.join(context.args)

    try:
        photo = update.message.photo[-1]

    except:
        photo = None
        file_path = None

    if photo:
        file_info = await context.bot.get_file(photo.file_id)
        id = file_info.file_id
        file_path = f"media/{id}.jpg"  # Укажите путь и имя файла
        file_bytes = await file_info.download_as_bytearray()
        with open(file_path, "wb") as f:
            f.write(file_bytes)

    ad = Rules(text=text)
    if file_path:
        ad.pic = file_path
    session.add(ad)
    session.commit()
    await update.message.reply_text('Теперь у вас новые правила :)')

async def new_rullete(update, context):
    text = update.message.caption
    if not text:
        text = ' '.join(context.args)

    try:
        photo = update.message.photo[-1]

    except:
        photo = None

    if photo:
        file_info = await context.bot.get_file(photo.file_id)
        id = file_info.file_id
        file_path = f"media/{id}.jpg"  # Укажите путь и имя файла
        file_bytes = await file_info.download_as_bytearray()
        with open(file_path, "wb") as f:
            f.write(file_bytes)
        ad = Roulettes(text=text)
        if file_path:
            ad.pic = file_path
        session.add(ad)
        session.commit()
        await update.message.reply_text('Теперь у вас новая инфа рулеток :)')
    else:
        ad = Roulettes(text=text)
        session.add(ad)
        session.commit()
        await update.message.reply_text('Теперь у вас новая инфа рулеток :)')

async def new_about(update, context):
    text = update.message.caption
    if not text:
        text = ' '.join(context.args)

    text = text.replace('/new_about ', '')
    try:
        photo = update.message.photo[-1]
    except:
        photo = None
        file_path = None
    if photo:
        file_info = await context.bot.get_file(photo.file_id)
        id = file_info.file_id
        file_path = f"media/{id}.jpg"  # Укажите путь и имя файла
        file_bytes = await file_info.download_as_bytearray()
        with open(file_path, "wb") as f:
            f.write(file_bytes)
    print(text)
    ad = About(text=text)
    if file_path:
        ad.pic = file_path

    session.add(ad)
    session.commit()
    await update.message.reply_text('Теперь у вас новая инфа рулеток :)')


def extract_value(input_text, keyword):
    start_index = input_text.find(keyword)
    if start_index != -1:
        end_index = input_text.find(';', start_index)
        if end_index != -1:
            return input_text[start_index + len(keyword):end_index].strip()
async def new_shop(update, context):
    print(update.message.caption)
    text = update.message.caption
    try:
        mess = '' + text
    except:
        mess = ' '.join(context.args)
    name = extract_value(mess, 'Название: ')
    bot = extract_value(mess, 'Бот: ')
    site = extract_value(mess, 'Сайт: ')
    status = extract_value(mess, 'Статус: ')
    contacts = extract_value(mess, 'Контакты: ')
    try:
        photo = update.message.photo[-1]
    except:
        photo = None
    file_path = None
    if photo:
        file_info = await context.bot.get_file(photo.file_id)
        id = file_info.file_id
        file_path = f"media/{id}.jpg"  # Укажите путь и имя файла
        file_bytes = await file_info.download_as_bytearray()
        with open(file_path, "wb") as f:
            f.write(file_bytes)

    if not session.query(Shops).filter(Shops.name == name).first():
        ad = Shops(name=name)
        if file_path:
            ad.pic = file_path
        if bot:
            ad.bot = bot
        if site:
            ad.site = site
        if status:
            if 'Проверенные' in status:
                ad.status = 'checked'
            elif 'Популярные' in status:
                ad.status = 'popular'
            elif 'На испытательном' in status:
                ad.status = 'new'
        if contacts:
            ad.contacts = contacts

        ad.callback_data = randint(2000, 4000)
        session.add(ad)
        session.commit()
        await update.message.reply_text('Теперь у вас новый магазин :)')
    else:
        ad = session.query(Shops).filter(Shops.name == name).first()
        print(ad)
        if photo:
            ad.pic = photo
        if bot:
            ad.bot = bot
        if site:
            ad.site = site
        if status:
            ad.status = status
        if contacts:
            ad.contacts = contacts

        session.add(ad)
        session.commit()
        await update.message.reply_text('Вы измeнили магазин :)')

async def del_shop(update, context):
    text = ' '.join(context.args)
    i = session.query(Shops).filter(Shops.name == text).one()
    if i:
        session.delete(i)
        session.commit()
        await update.message.reply_text('Магазин удалили :)')
    else:
        await update.message.reply_text('Нет такого магазина')


async def which_handler(update, context):
    text = update.message.caption
    if 'new_shop' in text:
        await new_shop(update, context)
    elif 'tell' in text:
        await tell(update, context)
    elif 'new_about' in text:
        await new_about(update, context)
    elif 'new_rule' in text:
        await new_rule(update, context)
    elif 'new_rullete' in text:
        await new_rullete(update, context)

async def tell(update, context):
    text = update.message.caption
    if not text:
        text = ' '.join(context.args)


    text = text.replace("/tell ", '')
    try:
        photo = update.message.photo[-1]
    except:
        photo = None

    file_path = None
    if photo:
        file_info = await context.bot.get_file(photo.file_id)
        id = file_info.file_id
        file_path = f"media\\{id}.jpg"  # Укажите путь и имя файла
        file_bytes = await file_info.download_as_bytearray()
        with open(file_path, "wb") as f:
            f.write(file_bytes)

    # chat = await context.bot.get_chat(update.message.chat_id)
    member_usernames = session.query(Users).all()
    for user in member_usernames:
        if file_path:
            await context.bot.send_photo(user.tg_id, photo=(open(f'{BASE_DIR}\\{file_path}', "rb")), caption=text)
        else:
            await context.bot.send_message(user.tg_id, text=text)


def main() -> None:
    TOKEN = '6450148918:AAExPgHSw3c9FvyOYfAJ5LIxP2vTxQBwu8w'
    # создание экземпляра бота через `ApplicationBuilder`
    application = ApplicationBuilder().token(TOKEN).build()
    start_handler = CommandHandler('start', start)
    button_handler = CallbackQueryHandler(button)
    application.add_handler(start_handler)
    application.add_handler(button_handler)
    new_admin_handler = CommandHandler('new_admin', new_admin)
    application.add_handler(new_admin_handler)
    del_admin_handler = CommandHandler('del_admin', del_admin)
    application.add_handler(del_admin_handler)
    rule_handler = CommandHandler('new_rule', new_rule)
    application.add_handler(rule_handler)
    new_shop_handler = CommandHandler('new_shop', new_shop)
    application.add_handler(new_shop_handler)
    new_rullete_handler = CommandHandler('new_rullete', new_rullete)
    application.add_handler(new_rullete_handler)
    del_shop_handler = CommandHandler('del_shop', del_shop)
    application.add_handler(del_shop_handler)
    new_about_handler = CommandHandler('new_about', new_about)
    application.add_handler(new_about_handler)
    application.add_handler(MessageHandler(filters.PHOTO & ~filters.COMMAND, which_handler))
    tell_handler = CommandHandler('tell', tell)
    application.add_handler(tell_handler)
    # запускаем приложение
    application.run_polling()

if __name__ == '__main__':
    main()